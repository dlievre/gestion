var fs = require("fs")
// ***** traitement super user
_super = (request, response) => { 
	// ***** chargement des modules
	    var express = require('express') // @ express
	    var app = express()
	    //var router = express.Router();
	    var bodyParser = require('body-parser')// @ body-parser, formate le request d'un form
	    app.use(bodyParser.json()) // pour format json
	    var multer = require('multer') // @ req.body récupère les champs d'un form
	    var upload = multer()
	    app.use(bodyParser.json()) //parsing application json
	    app.use(bodyParser.urlencoded({extended: true})) // parsing application x/www-form-urlencoded
	 
	    console.log('test')
	 
	    var _fonctions = require('../nodules/fonctions') // fonctions
	    var moduleDateFormat = require('date-format') // @ module date-format
	 
	        var info = new Object()
	        info.menu = 'superuser'
	        info.page = 'superuser'   
	        info.date = _myDate()
	        info.text = ''
	 
	var p1 = './routes'
var p = './nodules'

//obj.path=''

var  async  = require('async')
var  fs     = require('fs')

var results = [] 
var tblOut = []

async.waterfall([ 
	(callback)=>{
		fs.readdir(p1,(err, files)=>{
		   if (err) { return console.error(err) }
		   	console.log('files a '+files)
		   	callback(0, files)
		})
	}, //next

	(files, callback)=>{
		console.log('files b '+files)
		files.forEach( (file)=>{
			if (file.indexOf('.js') >= 0 || file.indexOf('.ejs') >= 0){
				console.log('file '+file)
				fs.readFile(p1+'/'+file, {encoding : 'utf8'}, (err, data) => {
						//console.log(typeof (tblOut))
					var tblIn = data.split("\n") // conversion en array avec \n comme delimiter
					for (nb = 0; nb < tblIn.length; nb++)
						tblOut += (nb+1)+' '+tblIn[nb]+'<br>'
					console.log('read '+file)
				})
			}
		
		})
		callback(0, tblOut)
	}
	], 
	//last
	function(err,tblOut){
		console.log('tblOut '+tblOut)
	})
	console.log('0**********************************************************')


async.waterfall([

	function(callback){
		var obj = new Object()
		newpath = []
		fs.readdir(p1, function (err, files){
			if (err) callback(true);
				for (var i=0; i<files.length;i++){
		 		if (files[i].indexOf('.js')>0 || files[i].indexOf('.ejs')>0){
		 			newpath.push(p+'/'+files[i])
		 		}
		 	}
			res = Object.assign({}, obj, {path: newpath})
		 	callback(false, res)
		});
	}, //next

	function(objfiles, callback){
		newpath = [...objfiles.path]
		fs.readdir(p1, function (err, files1){
			if (err) callback(true);
			for (var i=0; i<files1.length;i++){
		 		if (files1[i].indexOf('.js')>0 || files1[i].indexOf('.ejs')>0)
		 			newpath.push(p+'/'+files1[i])
		 	}
		 res = Object.assign({}, objfiles, {path: newpath})
		 callback(false, res)
		});
	}, //next

	function(res1, callback){
		resfic = []
		resorig = res1.path
	 	for (var i=0; i<res1.path.length;i++){
	 		if (resorig[i].indexOf('.js')>0 || resorig[i].indexOf('.ejs')>0)
	 			resfic.push(resorig[i])
	 	}
	 	
		callback(false, resfic)
	}, //next

	function(res2, callback){
	  	async.map(res2, fs.readFile, function(err,contents) {
	  		console.log('res2: '+res2)
		     if (err) { callback(err); } else {
		        callback(false,contents);
		     }
		   });
	}, //next

	function(res3, callback){
		res4 = ''
		for (var i=0;i<res3.length;i++){
			res4+= res3[i].toString().replace(/<\//g, '')+'\n'
		}
		callback(false, res4)
	}

],
	 //last
function(err,results){
	console.log(results)
})
console.log('1**********************************************************')

}
 
module.exports = (_super)


// 	suivi.path = './routes'
// 	var path = []
// 	path[0] = './routes'
// 	path[1] = './nodules'


// 	var filesAll = {fichiers: []}

// 	filesAll.fichiers.push('./routes') 
// console.log(filesAll)

// 	path0 = ()=>{ 
// 	_filesDir(filesAll.fichiers, path1)
// 	console.log('path0')
// 	}

// 	path1 = ()=>{ 
// 	_filesDir(path[1], suite1)
// 	console.log('path1')
// 	}

// path1()