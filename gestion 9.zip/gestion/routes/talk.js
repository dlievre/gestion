
// ***** traitement talk
_talk = (request, response, info) => { 

	// @ chargement des modules
	    var express = require('express') // @> express
	    var app = express()
	    //var router = express.Router();
	    var bodyParser = require('body-parser')// @> body-parser, formate le request d'un form
	    app.use(bodyParser.json()) // pour format json
	    var multer = require('multer') // req.body récupère les champs d'un form
	    var upload = multer()
	    app.use(bodyParser.json()) //parsing application json
	    app.use(bodyParser.urlencoded({extended: true})) // parsing application x/www-form-urlencoded
	 
	    if (request.body.n1){ 
	    info.menu = 'talk'
    	info.page = 'talk'   
    	info.niv = '1' 
    	console.log('n1')
		}
    if (request.body.n2){ 
    	info.menu = 'talk'
    	info.page = 'talk' 
    	info.niv = '2'
    	info.saisie = 'yes'  

    }

    	if (info.menu) response.render(info.page, { info })


			console.log('fin')
	
}

 
module.exports = (_talk)