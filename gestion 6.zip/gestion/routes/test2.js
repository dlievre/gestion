// ***** fichier test.js
var fs = require("fs")
 
_test2 = (request, response) => { // @ retourne la date formatée
    var express = require('express')
    var app = express()
    //var router = express.Router();
    var bodyParser = require('body-parser')// body-parser, formate le request d'un form
    app.use(bodyParser.json()) // pour format json
    var multer = require('multer') // req.body récupère les champs d'un form
    var upload = multer()
    app.use(bodyParser.json()) //parsing application json
    app.use(bodyParser.urlencoded({extended: true})) // parsing application x/www-form-urlencoded
 
    console.log('test')
 
    var _fonctions = require('../nodules/fonctions') // fonctions
 
        var info = new Object()
        info.menu = 'superuser'
        info.page = 'superuser'   
        info.date = _myDate()
        info.text = 'text'
 
    //console.log(theDate)
 
	var suivi = new Object()
	suivi.fin = 0
	suivi.nbFiles = 0
	suivi.niv2 = 'suite()'
	fichiers = ['./routes/users.js', './test/toto']

	async = require('async')

	async.waterfall(
	  [
	    // Lecture des fichiers
	    function(callback) { async.map(fichiers, fs.readFile, callback); },
	    // Écriture du fichier final avec la concaténation des contenus
	    function(contenus, callback) { fs.writeFile('fichierFinal', contenus.join(''), callback); },
	    //function(contenu, callbackb) { test(contenu,  callbackb); },

	    // Succès
	    function() { console.log('OK'); }
	  ],
	  // Erreur
	  function(err) { console.log('FAIL: ' + err.message); }
	);


}

test = (msg)=> {console.log('******************************'+msg)}

traitementFichier = (suivi)=>{
}

function _read (dirname)
{	fs.readdir(dirname,(err, files)=>{
	   if (err) {
	      return console.error(err)
	   }
	   	return (files)
	})
}

suite = ()=> {console.log('suite')}

// @ retourne la liste des fichiers d'un dossier
_filesDir = (dirname, callback)=> {
	fs.readdir(dirname,(err, files)=>{
	   if (err) {
	      return console.error(err)
	   }
	   	callback(files)
	})
}

_readFile = function(fichier, callback){ // @ lecture de fichier asynchrone

	fs.readFile(fichier, {encoding : 'utf8'}, (err, data) => {
			//console.log('data '+data)
			callback(data)
	})
}

 
 
module.exports = (_test2, _filesDir)

// async.waterfall(
//   [
//     // Lecture des fichiers
//     function(callback) { async.map(fichiers, fs.readFile, callback); },
//     // Écriture du fichier final avec la concaténation des contenus
//     function(contenus, callback) { fs.writeFile('fichierFinal', contenus.join(''), callback); },
//     // Succès
//     function() { console.log('OK'); }
//   ],
//   // Erreur
//   function(err) { console.log('FAIL: ' + err.message); }
// );
