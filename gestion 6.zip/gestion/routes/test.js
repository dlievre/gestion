// ***** fichier test.js
var fs = require("fs")
 
_test1 = (request, response) => { // @ retourne la date formatée
    var express = require('express')
    var app = express()
    //var router = express.Router();
    var bodyParser = require('body-parser')// body-parser, formate le request d'un form
    app.use(bodyParser.json()) // pour format json
    var multer = require('multer') // req.body récupère les champs d'un form
    var upload = multer()
    app.use(bodyParser.json()) //parsing application json
    app.use(bodyParser.urlencoded({extended: true})) // parsing application x/www-form-urlencoded
 
    console.log('test')
 
    var _fonctions = require('../nodules/fonctions') // fonctions
    //var theDate = myDate()
 
        var info = new Object()
        info.menu = 'superuser'
        info.page = 'superuser'   
        info.date = _myDate()
        info.text = 'text'
 
    //console.log(theDate)
 
 var suivi = new Object()
 suivi.fin = 0
 suivi.nbFiles = 0
 suivi.niv2 = 'suite()'


var p = './test'

var
  async     = require('async'),
  fs        = require('fs'),
  directoryFicJs;
 
function directoryListing(initialPath,callback) { //we can pass a variable into the first function used in async.seq - the resulting function can accept arguments and pass them this first function
  fs.readdir(initialPath,callback);
}
 
function arrayFsReadFile(fileNames,callback) {
  async.map(fileNames, function(fileName,readCallback) {
     fs.readFile(p+'/'+fileName,'utf8',readCallback);
  },
  function(err, contents) {
     if (err) { test(err); } else {
     	console.log('no err')
        callback(contents);
     }
   }
   );
}

function afficheContent(contents){
	console.log('no err suite')
	//console.log('err '+err)
	console.log(contents.toString())
}
 
//async.seq will produce a new function that you can use over and over
directoryFicJs = async.seq(
  directoryListing,
  arrayFsReadFile,
  afficheContent
);
 
directoryFicJs('./test');

    //response.render(info.page, { info })
 
//    info.date = _fonctions.myDate()
}

function rendu(response, request, content, tbl){
	console.log(content)
	response.render(info.page, { info, })
}

listFichier = (suivi, next)=>{
	console.log('listFichier')
	_filesDir('./routes', (files)=>{ 
		files.forEach( (file)=>{ 
			if (file.indexOf('.js') >= 0 || file.indexOf('.ejs') >= 0){
				++suivi.nbFiles
			}
		})
		console.log(suivi.nbFiles)

		files.forEach( (file)=>{ 
			if (file.indexOf('.js') >= 0 || file.indexOf('.ejs') >= 0){
				console.log('file : '+ file )
				++suivi.fin
				//_readFile(file, next)
				console.log('Suivi cb fin: '+suivi.fin)
				if (suivi.fin === suivi.nbFiles) { 
					console.log('render')
					//if(suivi.niv2) suivi.niv2
					next

				}		
			}
		})
	})
}

test = (msg)=> {console.log('******************************'+msg)}

traitementFichier = (suivi)=>{
}

function _read (dirname)
{	fs.readdir(dirname,(err, files)=>{
	   if (err) {
	      return console.error(err)
	   }
	   	return (files)
	})
}

suite = ()=> {console.log('suite')}

// @ retourne la liste des fichiers d'un dossier
_filesDir = (dirname, callback)=> {
	fs.readdir(dirname,(err, files)=>{
	   if (err) {
	      return console.error(err)
	   }
	   	callback(files)
	})
}

_readFile = function(fichier, callback){ // @ lecture de fichier asynchrone

	fs.readFile(fichier, {encoding : 'utf8'}, (err, data) => {
			//console.log('data '+data)
			callback(data)
	})
}

 
 
module.exports = (_test1, _filesDir)


// async.waterfall(
//   [
//     // Lecture des fichiers
//     function(callback) { async.map(fichiers, fs.readFile, callback); },
//     // Écriture du fichier final avec la concaténation des contenus
//     function(contenus, callback) { fs.writeFile('fichierFinal', contenus.join(''), callback); },
//     // Succès
//     function() { console.log('OK'); }
//   ],
//   // Erreur
//   function(err) { console.log('FAIL: ' + err.message); }
// );

// var i = 0
// var async = require('async')
// console.log('a')
// async.concat(['./nodules/','./routes/','./view/'], fs.readdir, (err, resultsa)=> {
//     // results is now an array of stats for each file

//         	for (i=0; i<resultsa.length;i++)
//         	{
//         		suivi.ab = 'var ab'
//         		console.log(resultsa[i])
//         	}

// })
// console.log('b')
// var i = 0
// async.map(['./routes/index.js','./routes/superuser.js','./routes/users.js'], fs.readFile, (err, results)=> {
//     // results is now an array of stats for each file


//         	for (i=0; i<results.length;i++)
//         	{

//         		//console.log(results[i].toString('utf8'))
//         	}

// })
// console.log('c')
